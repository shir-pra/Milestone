﻿using System;
using System.Collections.Generic;

namespace Milestone_LibraryManagementSystem.Models
{
    public partial class Tstudent
    {
        public Tstudent()
        {
            Tborrows = new HashSet<Tborrow>();
        }

        public int StudentId { get; set; }
        public string? StudentName { get; set; }
        public int? StudentAge { get; set; }
        public string? StudentLocation { get; set; }

        public virtual ICollection<Tborrow> Tborrows { get; set; }
    }
}
