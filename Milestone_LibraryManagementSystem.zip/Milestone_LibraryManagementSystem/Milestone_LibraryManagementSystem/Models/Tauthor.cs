﻿using System;
using System.Collections.Generic;

namespace Milestone_LibraryManagementSystem.Models
{
    public partial class Tauthor
    {
        public Tauthor()
        {
            Tbooks = new HashSet<Tbook>();
        }

        public int AuthorId { get; set; }
        public string? AuthorName { get; set; }
        public int? Reviews { get; set; }

        public virtual ICollection<Tbook> Tbooks { get; set; }
    }
}
