﻿using System;
using System.Collections.Generic;

namespace Milestone_LibraryManagementSystem.Models
{
    public partial class Tborrow
    {
        public int BorrowId { get; set; }
        public string? BorrowerName { get; set; }
        public int? StudentId { get; set; }
        public int? BookId { get; set; }

        public virtual Tbook? Book { get; set; }
        public virtual Tstudent? Student { get; set; }
    }
}
