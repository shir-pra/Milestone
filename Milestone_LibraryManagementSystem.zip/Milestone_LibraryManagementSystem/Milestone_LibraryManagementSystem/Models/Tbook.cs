﻿using System;
using System.Collections.Generic;

namespace Milestone_LibraryManagementSystem.Models
{
    public partial class Tbook
    {
        public Tbook()
        {
            Tborrows = new HashSet<Tborrow>();
        }

        public int BookId { get; set; }
        public string? BookName { get; set; }
        public int? AuthorId { get; set; }
        public int? Ratings { get; set; }

        public virtual Tauthor? Author { get; set; }
        public virtual ICollection<Tborrow> Tborrows { get; set; }
    }
}
