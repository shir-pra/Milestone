﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// The file which has been created after the scaffolding process
//Scaffoliding is the process of binding the database and creates model view controller files needed for the particular project

namespace Milestone_LibraryManagementSystem.Models
{
    public partial class LibrarymanagementContext : DbContext
    {
        public LibrarymanagementContext()
        {
        }

        public LibrarymanagementContext(DbContextOptions<LibrarymanagementContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Tauthor> Tauthors { get; set; } = null!;
        public virtual DbSet<Tbook> Tbooks { get; set; } = null!;
        public virtual DbSet<Tborrow> Tborrows { get; set; } = null!;
        public virtual DbSet<Tstudent> Tstudents { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
//                optionsBuilder.UseSqlServer("server=localhost;trusted_connection=true;database=Librarymanagement");
//            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Tauthor>(entity =>
            {
                entity.HasKey(e => e.AuthorId);

                entity.ToTable("TAuthors");

                entity.Property(e => e.AuthorName).HasMaxLength(50);
            });

            modelBuilder.Entity<Tbook>(entity =>
            {
                entity.HasKey(e => e.BookId);

                entity.ToTable("TBooks");

                entity.Property(e => e.BookName).HasMaxLength(50);

                entity.HasOne(d => d.Author)
                    .WithMany(p => p.Tbooks)
                    .HasForeignKey(d => d.AuthorId)
                    .HasConstraintName("FK__TBooks__AuthorId__3F466844");
            });

            modelBuilder.Entity<Tborrow>(entity =>
            {
                entity.HasKey(e => e.BorrowId);

                entity.ToTable("TBorrows");

                entity.Property(e => e.BorrowerName).HasMaxLength(50);

                entity.HasOne(d => d.Book)
                    .WithMany(p => p.Tborrows)
                    .HasForeignKey(d => d.BookId)
                    .HasConstraintName("FK__TBorrows__BookId__3E52440B");

                entity.HasOne(d => d.Student)
                    .WithMany(p => p.Tborrows)
                    .HasForeignKey(d => d.StudentId)
                    .HasConstraintName("FK__TBorrows__Studen__3D5E1FD2");
            });

            modelBuilder.Entity<Tstudent>(entity =>
            {
                entity.HasKey(e => e.StudentId);

                entity.ToTable("TStudents");

                entity.Property(e => e.StudentLocation)
                    .HasMaxLength(50)
                    .HasColumnName("Student_Location");

                entity.Property(e => e.StudentName).HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
