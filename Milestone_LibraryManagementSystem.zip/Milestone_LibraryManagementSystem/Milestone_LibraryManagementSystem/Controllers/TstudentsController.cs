﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Milestone_LibraryManagementSystem.Models;

namespace Milestone_LibraryManagementSystem.Controllers
{
    public class TstudentsController : Controller
    {
        private readonly LibrarymanagementContext _context;

        public TstudentsController(LibrarymanagementContext context)
        {
            _context = context;
        }

        // GET: Tstudents
        public async Task<IActionResult> Index()
        {
              return View(await _context.Tstudents.ToListAsync());
        }

        // GET: Tstudents/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Tstudents == null)
            {
                return NotFound();
            }

            var tstudent = await _context.Tstudents
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (tstudent == null)
            {
                return NotFound();
            }

            return View(tstudent);
        }

        // GET: Tstudents/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tstudents/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StudentId,StudentName,StudentAge,StudentLocation")] Tstudent tstudent)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tstudent);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tstudent);
        }

        // GET: Tstudents/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Tstudents == null)
            {
                return NotFound();
            }

            var tstudent = await _context.Tstudents.FindAsync(id);
            if (tstudent == null)
            {
                return NotFound();
            }
            return View(tstudent);
        }

        // POST: Tstudents/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("StudentId,StudentName,StudentAge,StudentLocation")] Tstudent tstudent)
        {
            if (id != tstudent.StudentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tstudent);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TstudentExists(tstudent.StudentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tstudent);
        }

        // GET: Tstudents/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Tstudents == null)
            {
                return NotFound();
            }

            var tstudent = await _context.Tstudents
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (tstudent == null)
            {
                return NotFound();
            }

            return View(tstudent);
        }

        // POST: Tstudents/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Tstudents == null)
            {
                return Problem("Entity set 'LibrarymanagementContext.Tstudents'  is null.");
            }
            var tstudent = await _context.Tstudents.FindAsync(id);
            if (tstudent != null)
            {
                _context.Tstudents.Remove(tstudent);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TstudentExists(int id)
        {
          return _context.Tstudents.Any(e => e.StudentId == id);
        }
    }
}
