﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Milestone_LibraryManagementSystem.Models;

namespace Milestone_LibraryManagementSystem.Controllers
{
    public class TbooksController : Controller
    {
        private readonly LibrarymanagementContext _context;

        public TbooksController(LibrarymanagementContext context)
        {
            _context = context;
        }

        // GET: Tbooks
        public async Task<IActionResult> Index()
        {
            var librarymanagementContext = _context.Tbooks.Include(t => t.Author);
            return View(await librarymanagementContext.ToListAsync());
        }

        // GET: Tbooks/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Tbooks == null)
            {
                return NotFound();
            }

            var tbook = await _context.Tbooks
                .Include(t => t.Author)
                .FirstOrDefaultAsync(m => m.BookId == id);
            if (tbook == null)
            {
                return NotFound();
            }

            return View(tbook);
        }

        // GET: Tbooks/Create
        public IActionResult Create()
        {
            ViewData["AuthorId"] = new SelectList(_context.Tauthors, "AuthorId", "AuthorId");
            return View();
        }

        // POST: Tbooks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BookId,BookName,AuthorId,Ratings")] Tbook tbook)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tbook);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["AuthorId"] = new SelectList(_context.Tauthors, "AuthorId", "AuthorId", tbook.AuthorId);
            return View(tbook);
        }

        // GET: Tbooks/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Tbooks == null)
            {
                return NotFound();
            }

            var tbook = await _context.Tbooks.FindAsync(id);
            if (tbook == null)
            {
                return NotFound();
            }
            ViewData["AuthorId"] = new SelectList(_context.Tauthors, "AuthorId", "AuthorId", tbook.AuthorId);
            return View(tbook);
        }

        // POST: Tbooks/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookId,BookName,AuthorId,Ratings")] Tbook tbook)
        {
            if (id != tbook.BookId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tbook);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TbookExists(tbook.BookId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["AuthorId"] = new SelectList(_context.Tauthors, "AuthorId", "AuthorId", tbook.AuthorId);
            return View(tbook);
        }

        // GET: Tbooks/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Tbooks == null)
            {
                return NotFound();
            }

            var tbook = await _context.Tbooks
                .Include(t => t.Author)
                .FirstOrDefaultAsync(m => m.BookId == id);
            if (tbook == null)
            {
                return NotFound();
            }

            return View(tbook);
        }

        // POST: Tbooks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Tbooks == null)
            {
                return Problem("Entity set 'LibrarymanagementContext.Tbooks'  is null.");
            }
            var tbook = await _context.Tbooks.FindAsync(id);
            if (tbook != null)
            {
                _context.Tbooks.Remove(tbook);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TbookExists(int id)
        {
          return _context.Tbooks.Any(e => e.BookId == id);
        }
    }
}
