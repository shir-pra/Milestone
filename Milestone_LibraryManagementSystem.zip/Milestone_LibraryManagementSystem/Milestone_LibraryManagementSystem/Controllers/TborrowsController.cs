﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Milestone_LibraryManagementSystem.Models;

namespace Milestone_LibraryManagementSystem.Controllers
{
    public class TborrowsController : Controller
    {
        private readonly LibrarymanagementContext _context;

        public TborrowsController(LibrarymanagementContext context)
        {
            _context = context;
        }

        // GET: Tborrows
        public async Task<IActionResult> Index()
        {
            var librarymanagementContext = _context.Tborrows.Include(t => t.Book).Include(t => t.Student);
            return View(await librarymanagementContext.ToListAsync());
        }

        // GET: Tborrows/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Tborrows == null)
            {
                return NotFound();
            }

            var tborrow = await _context.Tborrows
                .Include(t => t.Book)
                .Include(t => t.Student)
                .FirstOrDefaultAsync(m => m.BorrowId == id);
            if (tborrow == null)
            {
                return NotFound();
            }

            return View(tborrow);
        }

        // GET: Tborrows/Create
        public IActionResult Create()
        {
            ViewData["BookId"] = new SelectList(_context.Tbooks, "BookId", "BookId");
            ViewData["StudentId"] = new SelectList(_context.Tstudents, "StudentId", "StudentId");
            return View();
        }

        // POST: Tborrows/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BorrowId,BorrowerName,StudentId,BookId")] Tborrow tborrow)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tborrow);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["BookId"] = new SelectList(_context.Tbooks, "BookId", "BookId", tborrow.BookId);
            ViewData["StudentId"] = new SelectList(_context.Tstudents, "StudentId", "StudentId", tborrow.StudentId);
            return View(tborrow);
        }

        // GET: Tborrows/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Tborrows == null)
            {
                return NotFound();
            }

            var tborrow = await _context.Tborrows.FindAsync(id);
            if (tborrow == null)
            {
                return NotFound();
            }
            ViewData["BookId"] = new SelectList(_context.Tbooks, "BookId", "BookId", tborrow.BookId);
            ViewData["StudentId"] = new SelectList(_context.Tstudents, "StudentId", "StudentId", tborrow.StudentId);
            return View(tborrow);
        }

        // POST: Tborrows/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BorrowId,BorrowerName,StudentId,BookId")] Tborrow tborrow)
        {
            if (id != tborrow.BorrowId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tborrow);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TborrowExists(tborrow.BorrowId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["BookId"] = new SelectList(_context.Tbooks, "BookId", "BookId", tborrow.BookId);
            ViewData["StudentId"] = new SelectList(_context.Tstudents, "StudentId", "StudentId", tborrow.StudentId);
            return View(tborrow);
        }

        // GET: Tborrows/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Tborrows == null)
            {
                return NotFound();
            }

            var tborrow = await _context.Tborrows
                .Include(t => t.Book)
                .Include(t => t.Student)
                .FirstOrDefaultAsync(m => m.BorrowId == id);
            if (tborrow == null)
            {
                return NotFound();
            }

            return View(tborrow);
        }

        // POST: Tborrows/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Tborrows == null)
            {
                return Problem("Entity set 'LibrarymanagementContext.Tborrows'  is null.");
            }
            var tborrow = await _context.Tborrows.FindAsync(id);
            if (tborrow != null)
            {
                _context.Tborrows.Remove(tborrow);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TborrowExists(int id)
        {
          return _context.Tborrows.Any(e => e.BorrowId == id);
        }
    }
}
