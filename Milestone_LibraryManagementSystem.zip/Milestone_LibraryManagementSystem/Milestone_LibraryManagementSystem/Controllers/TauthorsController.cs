﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Milestone_LibraryManagementSystem.Models;

namespace Milestone_LibraryManagementSystem.Controllers
{
    public class TauthorsController : Controller
    {
        private readonly LibrarymanagementContext _context;

        public TauthorsController(LibrarymanagementContext context)
        {
            _context = context;
        }

        // GET: Tauthors
        public async Task<IActionResult> Index()
        {
              return View(await _context.Tauthors.ToListAsync());
        }

        // GET: Tauthors/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Tauthors == null)
            {
                return NotFound();
            }

            var tauthor = await _context.Tauthors
                .FirstOrDefaultAsync(m => m.AuthorId == id);
            if (tauthor == null)
            {
                return NotFound();
            }

            return View(tauthor);
        }

        // GET: Tauthors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Tauthors/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AuthorId,AuthorName,Reviews")] Tauthor tauthor)
        {
            if (ModelState.IsValid)
            {
                _context.Add(tauthor);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(tauthor);
        }

        // GET: Tauthors/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Tauthors == null)
            {
                return NotFound();
            }

            var tauthor = await _context.Tauthors.FindAsync(id);
            if (tauthor == null)
            {
                return NotFound();
            }
            return View(tauthor);
        }

        // POST: Tauthors/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AuthorId,AuthorName,Reviews")] Tauthor tauthor)
        {
            if (id != tauthor.AuthorId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(tauthor);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TauthorExists(tauthor.AuthorId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tauthor);
        }

        // GET: Tauthors/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Tauthors == null)
            {
                return NotFound();
            }

            var tauthor = await _context.Tauthors
                .FirstOrDefaultAsync(m => m.AuthorId == id);
            if (tauthor == null)
            {
                return NotFound();
            }

            return View(tauthor);
        }

        // POST: Tauthors/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Tauthors == null)
            {
                return Problem("Entity set 'LibrarymanagementContext.Tauthors'  is null.");
            }
            var tauthor = await _context.Tauthors.FindAsync(id);
            if (tauthor != null)
            {
                _context.Tauthors.Remove(tauthor);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TauthorExists(int id)
        {
          return _context.Tauthors.Any(e => e.AuthorId == id);
        }
    }
}
